	<!DOCTYPE html>
	<html lang="it">
	<head>
	    <link rel="icon" href="img/logo2.png" type="image/png" />
	<title>WebDefendo</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Exo" rel="stylesheet">
	<link href="style/style.css" rel="stylesheet" type="text/css">
	<link href="style/footer.css" rel="stylesheet" type="text/css">
	<link href="style/main.css" rel="stylesheet" type="text/css">
	<link href="style/nav.css" rel="stylesheet" type="text/css">
	
	
		<script >
		function showmenu() {
			if( document.getElementById("menu").style.display == "block")
				document.getElementById("menu").style.display = "none"
			else
				document.getElementById("menu").style.display = "block"
		}
		function resizemenu() {
			var x = window.innerWidth
			if (x >= 600)
				document.getElementById("menu").style.display = "block"
			else
				document.getElementById("menu").style.display = "none"
		}
		function closemenu() {
			var x = window.innerWidth
			if (x <= 600)
				document.getElementById("menu").style.display = "none"
		}
		
		function closecookie() {
				document.getElementById("infocookie").style.display="none"
		}
	</script>

	
	
	
	</head>
	<body  onload="f()" onresize="resizemenu()">
	
	<div id="infocookie">
	    
	        
	        <br>
	        <p>Il sito webdefendo.it utilizza i cookie, compresi i cookie di terze parti, per assicurarti la migliore esperienza all'interno del nostro sito. Se prosegui nella navigazione di questo sito acconsenti all'utilizzo dei cookie. Potrai modificare le tue preferenze e avere maggiori informazioni in qualsiasi momento consultando la sezione <a href="cookie/infocookie.pdf" onclick="closecookie()"><span>Cookie Policy</span></a></p>
	        <br>
	        <button id="cookieBtn" onclick="closecookie()">Accetto</button>
	        
	    
	    
	    
	</div>
	

		<div id="container">
				<nav class="navigation">
			<a  href="index.php">	
				<h3>WebDefendo</h3></a>
				<br>
				<div class="menubottone" align="left">
					<span margi class="menbtn" onclick="showmenu()">&#9776;</span>
					</div>
					<div class="tendina">
							<ul id="menu">
								<li><a href="index.php" onclick="closemenu()"><span>Home</span></a></li>
								<li><a href="chisiamo.php" onclick="closemenu()"><span>Chi Siamo</span></a></li>
								<li><a href="#contatti" onclick="closemenu()"><span>Contattaci</span></a></li>
							</ul>
					</div>
			</nav>



			<div id="main">
			    <br>
			    
			    	<div class="articolo">
					
					
					<h2 class="titolo">TITOLO</h2>
					<span class="data">dataprova</span>
					<span class="autore">autoreprova</span>
					<span class="tag">tagprova</span><br>
					<a class="fotoBox" href="#"><img src="img/prova.jpeg" >
				
					Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 	Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum
					</a>
					<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/it_IT/sdk.js#xfbml=1&version=v3.2';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-comments" data-href="https://developers.facebook.com/docs/plugins/comments#configurator" data-numposts="5"></div>
					
					<hr class="spazio">
				</div>
			    
			    
			</div>

		  <footer id="contatti">
				<img src="img/logo_trasparente.svg" width="140" height="140" alt="" />
				<h2>everybody must be safe on the web</h2>
				<div id="social_bar">
					<a href="#"><img src="img/fb.png" alt="Facebook" width="40"
						height="40" /> </a> <a href="#"><img src="img/insta.png"
						alt="Instagram" width="40" height="40" /> </a> <a href="#"><img
						src="img/twitter.png" alt="Twitter" width="40" height="40" /> </a> <a
						href="#"><img src="img/linkedin.png" alt="Linkedin" width="40"
						height="40" /> </a> <a href="#"><img src="img/youtube.png"
						alt="Youtube" width="40" height="40" /></a>
						
							<a href="#"><img src="img/telegram.png" alt="Telegram" width="40"
						height="40" /> </a>
				</div>
				<div id="legal">
					<ul>
						<li><a href="cookie/infocookie.pdf" onclick="closecookie()">Informative sulla privacy</a></li>
						<li><a href="cookie/infocookie.pdf" onclick="closecookie()">Cookie e pubblicit&agrave; su Internet</a></li>
					</ul>
					<span>WebDefendo</span>
				</div>
			</footer>
		</div>
	</body>
	</html>
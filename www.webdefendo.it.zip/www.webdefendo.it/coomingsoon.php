<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Comsoon</title>
    <link rel="stylesheet" href="style/stylecooming.css">
      <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.0.2/TweenMax.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
</head>
<body>


     <div class="backgroundimg">
         <div class="centro">

            <!--Adding heading-->
            <h1>COOMING SOON</h1>

            <!--Adding horizzonatl ruler-->
            <hr>

            <!--Adding paragraph-->
             <p id="demo" style="font-size: 30px"></p>

         </div>

     </div>

</body>

<script>
//Set the date we're counting down to
var countDown = new Date("Dec 31, 2018 00:00:00").getTime();
//Update the count down every 1 second
var countDownfunction = setInterval(function () {
//Get todays date and time
    var now = new Date().getTime();
    //Find the distance between now and the count down date
    var distance = countDown - now;
//Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 *60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 *24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    //Output the result in an element with id="demo"
    document.getElementById("demo").innerHTML = days + "d " + hours + "h " + minutes +"m " + seconds + "s ";
    //If the count down is over, write some text
    if(distance < 0){
        clearInterval(countDownfunction);
        document.getElementById("demo").innerHTML = "EXPIRED";
    }
},1000);

</script>

</html>
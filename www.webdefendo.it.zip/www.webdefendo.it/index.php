	<!DOCTYPE html>
	<html lang="it">
	<head>
	    <link rel="icon" href="img/logo2.png" type="image/png" />
	<title>WebDefendo</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Exo" rel="stylesheet">
	<link href="style/style.css" rel="stylesheet" type="text/css">
	<link href="style/footer.css" rel="stylesheet" type="text/css">
	<link href="style/main.css" rel="stylesheet" type="text/css">
	<link href="style/nav.css" rel="stylesheet" type="text/css">
	
	
		<script >
		function showmenu() {
			if( document.getElementById("menu").style.display == "block")
				document.getElementById("menu").style.display = "none"
			else
				document.getElementById("menu").style.display = "block"
		}
		function resizemenu() {
			var x = window.innerWidth
			if (x >= 600)
				document.getElementById("menu").style.display = "block"
			else
				document.getElementById("menu").style.display = "none"
		}
		function closemenu() {
			var x = window.innerWidth
			if (x <= 600)
				document.getElementById("menu").style.display = "none"
		}
		
		function closecookie() {
				document.getElementById("infocookie").style.display="none"
		}
	</script>

	
	
	
	</head>
	<body  onload="f()" onresize="resizemenu()">
	
	<div id="infocookie">
	    
	        
	        <br>
	        <p>Il sito webdefendo.it utilizza i cookie, compresi i cookie di terze parti, per assicurarti la migliore esperienza all'interno del nostro sito. Se prosegui nella navigazione di questo sito acconsenti all'utilizzo dei cookie. Potrai modificare le tue preferenze e avere maggiori informazioni in qualsiasi momento consultando la sezione <a href="cookie/infocookie.pdf" onclick="closecookie()"><span>Cookie Policy</span></a></p>
	        <br>
	        <button id="cookieBtn" onclick="closecookie()">Accetto</button>
	        
	    
	    
	    
	</div>
	

		<div id="container">
			<nav class="navigation">
			<a  href="index.php">	
				<h3>WebDefendo</h3></a>
				<br>
				<div class="menubottone" align="left">
					<span margi class="menbtn" onclick="showmenu()">&#9776;</span>
					</div>
					<div class="tendina">
							<ul id="menu">
								<li><a href="index.php" onclick="closemenu()"><span>Home</span></a></li>
								<li><a href="coomingsoon.php" onclick="closemenu()"><span>Chi Siamo</span></a></li>
								<li><a href="#contatti" onclick="closemenu()"><span>Contattaci</span></a></li>
							</ul>
					</div>
			</nav>



			<div id="main">
			    <br>
			    
			    	<div class="articolo">
					
					
					<h2 class="titolo">TITOLO</h2>
					<span class="data">dataprova</span>
					<span class="autore">autoreprova</span>
					<span class="tag">tagprova</span><br>
					<a class="fotoBox" href="articolo.php"><img src="img/prova.jpeg" >
				
					Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 	Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum
					</a>
					<hr class="spazio">
				</div>
			    
			    
				
				

			</div>
			<div class="boh2">
				<h3>Membri</h3>
				<div id="slider-bar">
					<div id="slider4" >
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Davide Bottiglieri</p>
								<p>Design Manager</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente"/>
								<p>Paolo Cantarella</p>
								<p>Social Manager</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Raffaele Marino</p>
								<p>Web Manager</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%; " alt="foto utente"/>
								<p>Angelo Fortunato</p>
								<p>Front-end Developer</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Mario Santoro</p>
								<p>Back-end Developer</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Alfonso Ruggiero</p>
								<p>Front-end Developer</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Giuseppe Cavaliere</p>
								<p>Facebook Promoter</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Matteo Pastore</p>
								<p>Twitter Promoter</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Silvio Corso</p>
								<p>LinkedIn Promoter</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Vincenzo Sabato</p>
								<p>Instagram Promoter</p>
							</a>
						</div>
						<div class="slide-img">
							<a href=""> <img src="img/no-image.png" style="width: 100%;" alt="foto utente" />
								<p>Erminio Acierno</p>
								<p>Human Resource</p>
							</a>
						</div>
					</div>
				</div>
			</div>

			<div class="boh" id="divMessage">
				<!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
				<!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
				<form name="sentMessage" id="contactForm" method="post" action="mail.php"  novalidate>
				<hr class="spazio">
				<br>
					<label>Nome</label> <br> <input class="form-control" id="name"
						type="text" placeholder="Name" required="required"
						data-validation-required-message="Please enter your name.">
					<br> <br> <label>Indirizzo Email</label> <br> <input
						class="form-control" id="email" type="email"
						placeholder="Email Address" required="required"
						data-validation-required-message="Please enter your email address.">
					<br> <br> <label>Numero di Telefono</label> <br> <input
						class="form-control" id="phone" type="tel"
						placeholder="Phone Number" required="required"
						data-validation-required-message="Please enter your phone number.">
					<br> <br> <label>Messaggio</label> <br>
					<textarea class="form-control" id="message" rows="5"
						placeholder="Message" required
						data-validation-required-message="Please enter a message."></textarea>
					<br> <br> <br>

					<button type="submit" class="button" id="sendMessageButton">Invia</button>
				</form>
			</div>

		  <footer id="contatti">
				<img src="img/logo_trasparente.svg" width="140" height="140" alt="" />
				<h2>everybody must be safe on the web</h2>
				<div id="social_bar">
					<a href="#"><img src="img/fb.png" alt="Facebook" width="40"
						height="40" /> </a> <a href="#"><img src="img/insta.png"
						alt="Instagram" width="40" height="40" /> </a> <a href="#"><img
						src="img/twitter.png" alt="Twitter" width="40" height="40" /> </a> <a
						href="#"><img src="img/linkedin.png" alt="Linkedin" width="40"
						height="40" /> </a> <a href="#"><img src="img/youtube.png"
						alt="Youtube" width="40" height="40" /></a>
						
							<a href="#"><img src="img/telegram.png" alt="Telegram" width="40"
						height="40" /> </a>
				</div>
				<div id="legal">
					<ul>
						<li><a href="cookie/infocookie.pdf" onclick="closecookie()">Informative sulla privacy</a></li>
						<li><a href="cookie/infocookie.pdf" onclick="closecookie()">Cookie e pubblicit&agrave; su Internet</a></li>
					</ul>
					<span>WebDefendo</span>
				</div>
			</footer>
		</div>
	</body>
	</html>